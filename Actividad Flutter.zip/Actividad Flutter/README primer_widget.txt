La aplicación consta de un botón en el medio de la pantalla que al ser precionado imprime 'Hola mundo' en la consola.
Para ejecutarlo se debe de pegar el código del archivo main.dart en la pagina dartpad.dev, en teoria deberia de funcionar en el emulador que
ofrece AndroidStudio, pero no puedo comprobarlo debido a las limitaciones de mi equipo