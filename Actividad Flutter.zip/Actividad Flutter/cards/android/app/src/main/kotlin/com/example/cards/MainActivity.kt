package com.example.cards

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
