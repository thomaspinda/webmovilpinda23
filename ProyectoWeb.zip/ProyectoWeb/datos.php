<?php
$host="localhost";
$bd="Usuario";
$user="postgres";
$pass= "bigboobz";

$conexion=pg_pconnect("host=$host dbname=$db user=$user password=$pass");

$query=("INSERT INTO Usuario(US_NOM, US_CONT)
VALUES(`_REQUEST[Usuario]`,`_REQUEST[Contraseña]`)");

$consulta=pg_query($conexion,$query);
if($consulta){
  echo "Datos insertados correctamente";
}
pg_close();
?>
